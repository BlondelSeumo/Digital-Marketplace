<?php return array (
  'checkout' => 'App\\Livewire\\Checkout',
  'item.comment-replies' => 'App\\Livewire\\Item\\CommentReplies',
  'item.comment-report' => 'App\\Livewire\\Item\\CommentReport',
  'item.comments' => 'App\\Livewire\\Item\\Comments',
  'item.comments-counter' => 'App\\Livewire\\Item\\CommentsCounter',
  'item.favorite-button' => 'App\\Livewire\\Item\\FavoriteButton',
  'newsletter.footer' => 'App\\Livewire\\Newsletter\\Footer',
  'newsletter.popup' => 'App\\Livewire\\Newsletter\\Popup',
);